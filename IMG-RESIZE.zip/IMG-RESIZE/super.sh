bash ../test.sh ${1} ../OUTPUT/${1}_${2}_${3}.png $2 $3
